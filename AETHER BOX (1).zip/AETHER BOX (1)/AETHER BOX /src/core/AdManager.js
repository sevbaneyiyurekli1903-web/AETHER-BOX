import bus from './EventBus.js';
import { EVENTS } from './Events.js';

/**
 * AdManager.js
 * -----------------------------------------------------------------
 * AdMob Reklam Yönetim Sistemi
 * 
 * SAYAÇ KURALLARI:
 * 1. Menü Geçişleri: 10 geçişte 1 Geçiş Reklamı
 * 2. Ayarlar Ses Aç/Kapa: 15 basışta SONSUZ REKLAM DÖNGÜSÜ (Bitmez)
 * 3. No Thanks (Yeniden Başlat): Toplam 3 basışta 1 Geçiş Reklamı
 * 4. Planet Merge Jokeri: Her basışta Ödüllü Reklam
 * 5. Canlanma (Revive): Her basışta Ödüllü Reklam
 * -----------------------------------------------------------------
 */

class AdManager {
  constructor() {
    this._menuTransitionCount = 0; // Hedef: 10
    this._soundToggleCount = 0;     // Hedef: 15 (Arka arkaya)
    this._noThanksCount = 0;         // Hedef: 3 (Toplama dayalı)
    
    // Sonsuz reklam modunun aktiflik durumu
    this._isInfiniteAdActive = false;
  }

  /**
   * 1. MENÜ GEÇİŞLERİ (Sayaç: 10)
   */
  handleMenuTransition(callback) {
    if (this._isInfiniteAdActive) return; // Sonsuz reklam modundaysa araya girme
    this._menuTransitionCount++;
    console.log(`[AdManager] Menü geçiş sayacı: ${this._menuTransitionCount}/10`);

    if (this._menuTransitionCount >= 10) {
      this._menuTransitionCount = 0;
      this._showInterstitialAd(callback);
    } else {
      if (callback) callback();
    }
  }

  /**
   * 2. AYARLAR SES BUTONU (Sayaç: 15 -> SONSUZ REKLAM)
   * Ses butonuna 15 kez basıldığında durmaksızın sonsuz reklam başlatır.
   */
  handleSoundToggle(callback) {
    if (this._isInfiniteAdActive) return;

    this._soundToggleCount++;
    console.log(`[AdManager] Ses butonu sayacı (Gizli): ${this._soundToggleCount}/15`);

    if (this._soundToggleCount >= 15) {
      this._soundToggleCount = 0;
      this._startInfiniteAdLoop(); // Sonsuz döngüyü başlat
    } else {
      if (callback) callback();
    }
  }

  /**
   * 3. OYUN KAYBEDİLDİĞİNDE "NO THANKS" (Sayaç: 3)
   */
  handleDeathRestart(callback) {
    if (this._isInfiniteAdActive) return;

    this._noThanksCount++;
    console.log(`[AdManager] "No Thanks" sayacı: ${this._noThanksCount}/3`);

    if (this._noThanksCount >= 3) {
      this._noThanksCount = 0;
      this._showInterstitialAd(callback);
    } else {
      if (callback) callback();
    }
  }

  /**
   * 4. CANLANMA REKLAMI (Watch Ad / Revive)
   */
  showReviveAd(onSuccess, onFailure) {
    console.log('[AdManager] Ödüllü Reklam İstendi: Canlanma');
    this._showRewardedAd('Revive', onSuccess, onFailure);
  }

  /**
   * 5. PLANET MERGE JOKER REKLAMI
   */
  showJokerAd(onSuccess, onFailure) {
    console.log('[AdManager] Ödüllü Reklam İstendi: Planet Merge Joker');
    this._showRewardedAd('Joker', onSuccess, onFailure);
  }

  // -----------------------------------------------------------------
  // ♾️ SONSUZ REKLAM DÖNGÜSÜ MANTIĞI (Infinite Ad Loop)
  // -----------------------------------------------------------------

  /**
   * Sonsuz reklam modunu kilitler ve döngüyü başlatır.
   */
  _startInfiniteAdLoop() {
    this._isInfiniteAdActive = true;
    console.log('⚠️ [AdManager] GİZLİ SONSUZ REKLAM MODU BAŞLATILDI!');
    this._playNextInfiniteAd();
  }

  /**
   * Reklam her bittiğinde / kapatıldığında anında yenisini açan döngü
   */
  _playNextInfiniteAd() {
    if (!this._isInfiniteAdActive) return;

    console.log('[AdManager] 🎬 Sonsuz Reklam Gösteriliyor...');

    /*
     * Gerçek AdMob SDK Entegrasyonunda:
     * window.admob.interstitial.show().then(() => {
     *    // Reklam kapatılma event'inde (onDismissed) tekrar kendini çağırır:
     *    this._playNextInfiniteAd();
     * });
     */

    // Simülasyon: Reklam süresi biter bitmez hemen yenisi başlatılır (Asla son bulmaz)
    setTimeout(() => {
      console.log('[AdManager] 🔄 Reklam bitti/kapatıldı -> ANINDA YENİ REKLAM AÇILIYOR...');
      this._playNextInfiniteAd(); // Kendi kendini sonsuza kadar tekrarlar
    }, 2000);
  }

  // -----------------------------------------------------------------
  // ADMOB SDK ADAPTERS (Normal Reklamlar)
  // -----------------------------------------------------------------

  /** Normal Geçiş Reklamı (Interstitial) */
  _showInterstitialAd(callback) {
    console.log('[AdManager] 🎬 AdMob Geçiş Reklamı Gösteriliyor...');
    setTimeout(() => {
      console.log('[AdManager] ✅ Geçiş reklamı tamamlandı');
      bus.emit(EVENTS.AD_INTERSTITIAL_SHOWN);
      if (callback) callback();
    }, 1500);
  }

  /** Ödüllü Reklam (Rewarded) */
  _showRewardedAd(type, onSuccess, onFailure) {
    console.log(`[AdManager] 🎁 AdMob Ödüllü Reklam Gösteriliyor [${type}]...`);
    setTimeout(() => {
      console.log(`[AdManager] ✅ Ödüllü reklam tamamlandı [${type}]`);
      if (onSuccess) onSuccess();
    }, 2000);
  }

  /** Sıfırlama gerekirse */
  resetCounters() {
    this._menuTransitionCount = 0;
    this._soundToggleCount = 0;
    this._noThanksCount = 0;
    this._isInfiniteAdActive = false;
    console.log('[AdManager] Tüm sayaçlar ve sonsuz reklam modu sıfırlandı');
  }
}

const adManager = new AdManager();
export default adManager;
