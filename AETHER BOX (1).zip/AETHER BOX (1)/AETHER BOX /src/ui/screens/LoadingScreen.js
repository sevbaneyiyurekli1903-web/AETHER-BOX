import bus from '../../core/EventBus.js';
import { EVENTS } from '../../core/Events.js';
import i18n from '../../core/I18nManager.js';

export class LoadingScreen {
  constructor() {
    this.element = null;
    this._timerId = null;
    this._onComplete = null;
  }

  render() {
    // Sayfa gövdesi kaydırma çubuklarını tamamen engelle
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.overflow = 'hidden';

    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay hidden';
    overlay.id = 'loading-overlay';

    // Arka planı görselin kendi siyah rengiyle tam bütünleştiriyoruz
    Object.assign(overlay.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
      width: '100vw',
      height: '100vh',
      height: '100dvh',
      zIndex: '999999',
      backgroundColor: '#000000', // Görselin siyah arka planı ile kusursuz birleşir
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      overflow: 'hidden',
      margin: '0',
      padding: '0'
    });

    const img = document.createElement('img');
    img.className = 'loading-image';
    img.src = 'assets/images/loading-bg.png';
    img.alt = 'Loading...';

    // Yazının esnemesini VE yanlardan kesilmesini önleyen oranlama
    Object.assign(img.style, {
      width: '150%',          // Yanlardan asla taşmaz veya kesilmez
      maxWidth: '450px',     // Tablet ve büyük ekranlarda aşırı büyümesini engeller
      height: 'auto',        // En-boy oranını korur, yazıyı ASLA esnetmez
      maxHeight: '85vh',     // Dikeyde ekrandan taşmayı engeller
      objectFit: 'contain',
      display: 'block'
    });

    overlay.appendChild(img);
    this.element = overlay;
    return overlay;
  }

  show(onComplete) {
    this._onComplete = onComplete;
    this.element.classList.remove('hidden');
    if (this._timerId) clearTimeout(this._timerId);
    this._timerId = setTimeout(() => {
      this.hide();
      if (typeof this._onComplete === 'function') this._onComplete();
    }, 5000);
  }

  hide() {
    this.element.classList.add('hidden');
    if (this._timerId) {
      clearTimeout(this._timerId);
      this._timerId = null;
    }
  }
}
